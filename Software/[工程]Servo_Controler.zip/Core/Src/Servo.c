//
// Created by AQin on 2023/6/24.
//

#include "Servo.h"

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;

TIM_HandleTypeDef* pubTIM;
uint16_t pubChn;
double pubDuty;

static double map(double val, double oldMin, double oldMax, double newMin, double newMax)
{
    return newMin + (val - oldMin) / (oldMax - oldMin) * (newMax - newMin);
}

void TIM_ServoInit()
{
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);

    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
}

void TIM_ChannelSetDuty(TIM_HandleTypeDef* htim, uint16_t channel, uint16_t compare)
{
    __HAL_TIM_SET_COMPARE(htim, channel, compare);
}

void TIM_ServoSetAngle(uint8_t timIndex, uint16_t channelIndex, double angle, int fullAngle)
{
    //COMPARE: ARR * 占空比

    //确定要设置的定时器
    switch (timIndex)
    {
        case 1:pubTIM = &htim1;break;
        case 2:pubTIM = &htim2;break;
        case 3:pubTIM = &htim3;break;
        case 4:pubTIM = &htim4;break;
        default:break;
    }
    //确定通道
    switch (channelIndex)
    {
        case 1:pubChn = TIM_CHANNEL_1;break;
        case 2:pubChn = TIM_CHANNEL_2;break;
        case 3:pubChn = TIM_CHANNEL_3;break;
        case 4:pubChn = TIM_CHANNEL_4;break;
        default:break;
    }

    pubDuty = map(angle, 0, fullAngle, 0.025, 0.125);
    TIM_ChannelSetDuty(pubTIM, pubChn, 999 * pubDuty);
}
