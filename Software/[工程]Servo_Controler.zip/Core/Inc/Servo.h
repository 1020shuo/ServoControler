//
// Created by AQin on 2023/6/24.
//

#ifndef SERVO_H
#define SERVO_H
#include "main.h"


static double map(double val, double oldMin, double oldMax, double newMin, double newMax);
void TIM_ServoInit();
void TIM_ChannelSetDuty(TIM_HandleTypeDef* htim, uint16_t channel, uint16_t compare);
void TIM_ServoSetAngle(uint8_t timIndex, uint16_t channelIndex, double angle, int fullAngle);

#endif //SERVO_H
